﻿namespace Game_Project.Character.Enemy;

public class MiniBoss : StandardEnemy
{
    public MiniBoss(string enemyName, ulong level, ulong schaden, ulong maxLeben, ulong aktuellesLeben) : base(enemyName, level, schaden, maxLeben, aktuellesLeben)
    {
        
    }
}