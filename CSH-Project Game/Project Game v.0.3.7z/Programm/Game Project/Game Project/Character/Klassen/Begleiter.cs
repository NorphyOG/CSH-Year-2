﻿namespace Game_Project.Character.Klassen;

public class Begleiter : StandardKlasse
{
    public Begleiter(string characterName, ulong level, double maxMaxErfahrung, double aktuelleErfahrung, ulong schaden, ulong maxLeben, ulong aktuellesLeben, ulong maxActionPoints, ulong aktuelleActionPoints, ulong skillPoints, bool isDead) : base(characterName, level, maxMaxErfahrung, aktuelleErfahrung, schaden, maxLeben, aktuellesLeben, maxActionPoints, aktuelleActionPoints, skillPoints, isDead)
    {
        
    }
}