﻿// See https://aka.ms/new-console-template for more information

using Game_Project;

GameStart gameStart = new GameStart();

gameStart.Start();



