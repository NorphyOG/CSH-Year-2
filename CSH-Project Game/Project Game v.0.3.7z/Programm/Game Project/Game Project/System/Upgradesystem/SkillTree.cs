﻿namespace Game_Project.Upgradesystem;

public class SkillTree
{
    
}