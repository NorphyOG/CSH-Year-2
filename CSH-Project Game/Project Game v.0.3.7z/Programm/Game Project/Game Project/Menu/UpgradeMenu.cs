﻿namespace Game_Project.Menu;

public class UpgradeMenu
{
    
}