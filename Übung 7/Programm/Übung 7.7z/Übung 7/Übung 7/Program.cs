﻿// See https://aka.ms/new-console-template for more information

using Übung_7;

Menu menu = new Menu();

menu.Start();

