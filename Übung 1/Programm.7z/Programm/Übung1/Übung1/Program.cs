﻿// See https://aka.ms/new-console-template for more information

using Übung1;

Console.WriteLine("Hello, World!");

new Messung();
