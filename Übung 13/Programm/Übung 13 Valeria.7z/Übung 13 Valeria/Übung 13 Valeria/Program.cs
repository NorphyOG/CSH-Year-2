﻿// See https://aka.ms/new-console-template for more information

using Übung_13_Valeria;

    FileRead fileread = new FileRead();
    fileread.AlleDateiLesen();
    fileread.speichern();
